//
//  VerifyFrameWork.h
//  VerifyFrameWork
//
//  Created by Jane on 2020/7/20.
//  Copyright © 2020 Jane. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for VerifyFrameWork.
FOUNDATION_EXPORT double VerifyFrameWorkVersionNumber;

//! Project version string for VerifyFrameWork.
FOUNDATION_EXPORT const unsigned char VerifyFrameWorkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VerifyFrameWork/PublicHeader.h>

//使用的类
#import <Verify5Client/Verify5ClientView.h>
